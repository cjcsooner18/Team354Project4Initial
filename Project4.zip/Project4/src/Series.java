import java.util.ArrayList;

/**
 * Project #4
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Parses and constructs series objects.
 * </p>
 * @version 1.0
 *
 */
public class Series extends Media {
	/**
	 * String representation of the end year of a series.
	 */
	String endYear;
	
	/**
	 * An arraylist of the episodes in a series.
	 */
	ArrayList<Episodes> episodes = new ArrayList<Episodes>();
	
	/**
	 * Constructor for series objects.
	 * @param line String from a text file to parse into a series object.
	 */
	public Series(String line) {
		
	}
	
	/**
	 * Gets the end year of the series.
	 * @return String of the end year.
	 */
	public String getEndYear() {
		return "";
	}
	
	/**
	 * Gets the episodes in the series.
	 * @return ArrayList of the episodes.
	 */
	public ArrayList<Episodes> getEpisodes() {
		return null;
	}
	
	/**
	 * Gets a String representation of the series object.
	 * @return String representation of the series object.
	 */
	public String toString() {
		return "";
	}
}
