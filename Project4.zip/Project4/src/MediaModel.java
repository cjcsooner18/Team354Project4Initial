import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * MVC model.
 * </p>
 * @version 1.0
 *
 */
public class MediaModel {
	/**
	 * List to keep track of registered action listeners.
	 */
	private ArrayList<ActionListener> actionListenerList = new ArrayList<ActionListener>();
	
	/**
	 * Constructor for MediaModel.
	 */
	public MediaModel() {
		
	}
	
	/**
	 * Adds media objects.
	 * @param obj The media object to add.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean addMedia(Media obj) {
		return false;
	}
	
	/**
	 * Edits media objects.
	 * @param obj The media object to edit.
	 * @return boolean indicating whether the action was performed.
	 */
	public boolean editMedia(Media obj) {
		return false;
	}
	
	/**
	 * Deletes media objects.
	 * @param obj The media object to delete.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean deleteMedia(Media obj) {
		return false;
	}
	
	/**
	 * Clears media objects.
	 * @param obj The media object to clear.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean clearMedia(Media obj) {
		return false;
	}
	
	/**
	 * Clears all media.
	 */
	public void clearAll() {
		
	}
	
	/**
	 * Loads media objects.
	 * @param obj The media object to be loaded.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean loadMedia(Media obj) {
		return false;
	}
	
	/**
	 * Saves media objects.
	 * @param obj The media object to be saved.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean saveMedia(Media obj) {
		return false;
	}
	
	/**
	 * Imports media objects.
	 * @param file File name of file to import media.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean importMedia(String file) {
		return false;
	}
	
	/**
	 * Exports media objects.
	 * @return boolean indicating whether or not the action was performed.
	 */
	public boolean exportMedia() {
		return false;
	}
	
	/**
	 * Registers action listeners.
	 * @param l ActionListener to be registered.
	 */
	public void addActionListener(ActionListener l) {
		
	}
	
	/**
	 * Removes action listeners.
	 * @param l ActionListener to be removed.
	 */
	public void removeActionListener(ActionListener l) {
		
	}
	
	/**
	 * Processes the action events from the action listeners.
	 * @param e
	 */
	public void processEvent(ActionEvent e) {
		
	}
}
