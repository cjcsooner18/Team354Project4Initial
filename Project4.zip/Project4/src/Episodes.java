/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Parses and constructs episode objects.
 * </p>
 * @version 1.0
 *
 */
public class Episodes extends Media {
	/**
	 * Stores the episode number of the episode.
	 */
	String episodeNumber;
	
	/**
	 * Stores the season number of the episode.
	 */
	String seasonNumber;
	
	/**
	 * Constructs episode objects.
	 * @param line String line from text files to construct episodes.
	 */
	public Episodes(String line) {
		
	}
	
	/**
	 * Gets the episode number of the episode.
	 * @return String of the episode number.
	 */
	public String getEpisodeNumber() {
		return "";
	}
	
	/**
	 * Gets the season number of the episode.
	 * @return String of the season number.
	 */
	public String getSeasonNumber() {
		return "";
	}
	
	/**
	 * Turns the episode object into a String.
	 * @return String representation of the episode object.
	 */
	public String toString() {
		return "";
	}
}
