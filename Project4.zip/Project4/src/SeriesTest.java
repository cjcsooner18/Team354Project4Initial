import static org.junit.Assert.*;

import org.junit.Test;

public class SeriesTest {

	@Test
	public void test() {
		String series = "Star Trek Begins (2014)				2014-????";
		Series s = new Series(series);
		assertEquals(s.getTitle(), "Star Trek Begins");
		assertEquals(s.getReleaseYear(), "2014");
		assertEquals(s.getEndYear(), "2014-????");
	}

}
