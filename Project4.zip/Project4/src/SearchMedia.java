import java.util.ArrayList;

/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Contains all search and sort functions for the media class.
 * </p>
 * @version 1.0
 *
 */
public class SearchMedia {
	
	/**
	 * Sorts media list alphabetically by title.
	 * @param media The ArrayList to be sorted.
	 */
	public void sortList(ArrayList<Media> media) {
		
	}
	
	/**
	 * Sorts media list by year.
	 * @param media The ArrayList to be sorted.
	 */
	public void sortListByYear(ArrayList<Media> media) {
		
	}
	
	/**
	 * Searches for an exact media object by title.
	 * @param media The ArrayList to search through.
	 * @param title The title to search by.
	 * @return The exact media object.
	 */
	public Media searchListExact(ArrayList<Media> media, String title) {
		return null;
	}
	
	/**
	 * Searches for an exact media object by title and year.
	 * @param media The ArrayList to search through.
	 * @param title The title to search by.
	 * @param year The year to search by.
	 * @return The exact media object.
	 */
	public Media searchListExact(ArrayList<Media> media, String title, String year) {
		return null;
	}
	
	/**
	 * Searches for a partial match by title or year.
	 * @param media The ArrayList to search through.
	 * @param title The title or year to search by.
	 * @return An ArrayList of the partial matches.
	 */
	public ArrayList<Media> searchListPartial(ArrayList<Media> media, String title) {
		return null;
	}
	
	/**
	 * Searches for a partial match by title and year.
	 * @param media The ArrayList to search through.
	 * @param year The year to search by.
	 * @param title The title to search by.
	 * @return An ArrayList of the partial matches.
	 */
	public ArrayList<Media> searchListPartial(ArrayList<Media> media, String year, String title) {
		return null;
	}
}
