import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Parses and constructs mediamaker objects.
 * </p>
 * @version 1.0
 *
 */
public class Mediamaker {
	/**
	 * Stores all of the mediamakers in an accessible LinkedHashMap.
	 */
	LinkedHashMap people;
	
	/**
	 * ArrayList of media objects of the movies the actor has acted in.
	 */
	ArrayList<Media> moviesActed = new ArrayList<Media>();
	
	/**
	 * ArrayList of media objects that the mediamaker has produced.
	 */
	ArrayList<Media> moviesProduced = new ArrayList<Media>();
	
	/**
	 * ArrayList of media objects that have been directed by the mediamaker.
	 */
	ArrayList<Media> moviesDirected = new ArrayList<Media>();
	
	/**
	 * Parses and constructs mediamaker objects.
	 * @param line Takes in a String with the information pertaining to the mediamaker.
	 */
	public Mediamaker(String line) {
		
	}
	
	/**
	 * Gets the movies that the person acted in.
	 * @return ArrayList of the movies acted in.
	 */
	public ArrayList<Media> getMoviesActed() {
		return null;
	}
	
	/**
	 * Gets the movies that were directed.
	 * @return ArrayList of the movies directed.
	 */
	public ArrayList<Media> getMoviesDirected() {
		return null;
	}
	
	/**
	 * Gets the movies that were produced.
	 * @return ArrayList of the movies that were produced.
	 */
	public ArrayList<Media> getMoviesProduced() {
		return null;
	}
	
	/**
	 * Turns the mediamaker object into a String.
	 * @return String representation of the mediamaker object.
	 */
	public String toString() {
		return "";
	}
}
