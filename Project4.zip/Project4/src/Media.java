import java.io.Serializable;
import java.util.Comparator;

/**
 * Project #4
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Superclass for all movie, episode, and series objects.
 * </p>
 * @version 1.0
 *
 */
public class Media implements Comparable<Media>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * String object that stores the title of the media object.
	 */
	String title;
	
	/**
	 * Release year of the media object.
	 */
	String releaseYear;
	
	/**
	 * Constructor for the media class.
	 */
	public Media() {
		
	}
	
	/**
	 * Gets the title of the media object.
	 * @return String of the title.
	 */
	public String getTitle() {
		return "";
	}
	
	/**
	 * Gets the release year.
	 * @return String representation of the release year.
	 */
	public String getReleaseYear() {
		return "";
	}
	
	/**
	 * Compares two media objects based on their titles (natural ordering).
	 * @param obj Media object to compare to.
	 * @return int representation of the comparison between the two.
	 */
	@Override
	public int compareTo(Media obj) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public class YearComparator implements Comparator<Media> {
		/**
		 * Compares two media objects based on their release years.
		 * @param arg0 The first media object to compare to.
		 * @param arg1 The second media object to compare to.
		 * @return An int representation of the comparison between the two.
		 */
		@Override
		public int compare(Media arg0, Media arg1) {
			// TODO Auto-generated method stub
			return 0;
		}
	}
}
