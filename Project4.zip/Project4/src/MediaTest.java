import static org.junit.Assert.*;

import org.junit.Test;

public class MediaTest {

	@Test
	public void test() {
		Movie m = new Movie("The Star Wars Holiday Special (1978) (TV) 1978");
		assertEquals(m.getTitle(), "The Star Wars Holiday Special");
		assertEquals(m.getReleaseYear(), "1978");
		assertEquals(m.getVenue(), "TV");
		
		Movie n = new Movie("Our Star Trek Moment (2014) (V) 2014");
		assertTrue(m.compareTo(n) > 0);
		assertTrue(n.compareTo(m) < 0);
		assertTrue(m.compareTo(m) == 0);
	}

}
