import static org.junit.Assert.*;

import org.junit.Test;

public class EpisodesTest {

	@Test
	public void test() {
		String episode = "Star Trek Anthology (2015) {Another Door Opens (#1.1)}	2015";
		Episodes e = new Episodes(episode);
		assertEquals(e.getTitle(), "Another Door Opens");
		assertEquals(e.getReleaseYear(), "2015");
		assertEquals(e.getEpisodeNumber(), "1");
		assertEquals(e.getSeasonNumber(), "1");
	}

}
