import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 * Project #4
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * MVC controller.
 * </p>
 * @version 1.0
 *
 */
public class MediaInputWindow {
	/**
	 * Button to pick the media setting.
	 */
	JButton jbtMedia = new JButton();
	
	/**
	 * Button to pick movies.
	 */
	JButton jbtMovies = new JButton();
	
	/**
	 * Button to pick series.
	 */
	JButton jbtSeries = new JButton();
	
	/**
	 * Button to pick episodes.
	 */
	JButton jbtEpisodes = new JButton();
	
	/**
	 * Button to pick makers setting.
	 */
	JButton jbtMakers = new JButton();
	
	/**
	 * Button to pick actors.
	 */
	JButton jbtActors = new JButton();
	
	/**
	 * Button to pick directors.
	 */
	JButton jbtDirectors = new JButton();
	
	/**
	 * Button to pick producers.
	 */
	JButton jbtProducers = new JButton();
	
	/**
	 * Label for the selection pane.
	 */
	JLabel jlblSelection = new JLabel();
	
	/**
	 * Label for the display pane.
	 */
	JLabel jlblDisplay = new JLabel();
	
	/**
	 * Menu bar.
	 */
	JMenuBar menuBar = new JMenuBar();
	
	/**
	 * File menu.
	 */
	JMenu file = new JMenu();
	
	/**
	 * Edit menu.
	 */
	JMenu edit = new JMenu();
	
	/**
	 * Display menu.
	 */
	JMenu display = new JMenu();
	
	/**
	 * Load item for file menu.
	 */
	JMenuItem load = new JMenuItem();
	
	/**
	 * Save item for file menu.
	 */
	JMenuItem save = new JMenuItem();
	
	/**
	 * Import item for file menu.
	 */
	JMenuItem importButton = new JMenuItem();
	
	/**
	 * Export item for file menu.
	 */
	JMenuItem export = new JMenuItem();
	
	/**
	 * Add item for edit menu.
	 */
	JMenuItem add = new JMenuItem();
	
	/**
	 * Edit item for edit menu.
	 */
	JMenuItem editButton = new JMenuItem();
	
	/**
	 * Delete item for edit menu.
	 */
	JMenuItem delete = new JMenuItem();
	
	/**
	 * Clear item for edit menu.
	 */
	JMenuItem clear = new JMenuItem();
	
	/**
	 * Clear all item for edit menu.
	 */
	JMenuItem clearAll = new JMenuItem();
	
	/**
	 * Pie chart item for display menu.
	 */
	JMenuItem pieChart = new JMenuItem();
	
	/**
	 * Histogram item for display menu.
	 */
	JMenuItem histogram = new JMenuItem();
	
	/**
	 * Constructor for MediaInputWindow.
	 */
	public MediaInputWindow() {
		
	}
	
	/**
	 * Method to clear input fields.
	 */
	public void clearInputFields() {
		
	}
	
	/**
	 * Registers add media listener.
	 * @param addMediaListener Listener to register.
	 */
	public void addAddMediaButtonListener(ActionListener addMediaListener) {
		
	}
	
	/**
	 * Registers edit media listener.
	 * @param editMediaListener Listener to register.
	 */
	public void addEditMediaButtonListener(ActionListener editMediaListener) {
		
	}
	
	/**
	 * Registers delete media listener.
	 * @param deleteMediaListener Listener to register.
	 */
	public void addDeleteMediaButtonListener(ActionListener deleteMediaListener) {
		
	}
	
	/**
	 * Registers clear media listener.
	 * @param clearMediaListener Listener to register.
	 */
	public void addClearMediaButtonListener(ActionListener clearMediaListener) {
		
	}
	
	/**
	 * Registers clear all media listener.
	 * @param clearAllMediaListener Listener to register.
	 */
	public void addClearAllMediaButtonListener(ActionListener clearAllMediaListener) {
		
	}
	
	/**
	 * Registers clear input fields listener.
	 * @param clearInputFieldsListener Listener to register.
	 */
	public void addClearInputFieldsButtonListener(ActionListener clearInputFieldsListener) {
		
	}
	
	/**
	 * Registers load listener.
	 * @param loadListener Listener to register.
	 */
	public void addLoadMediaButtonListener(ActionListener loadMediaListener) {
		
	}
	
	/**
	 * Registers import listener.
	 * @param importMediaListener Listener to register.
	 */
	public void addImportMediaButtonListener(ActionListener importMediaListener) {
		
	}
	
	/**
	 * Registers export listener.
	 * @param exportMediaListener Listener to register.
	 */
	public void addExportMediaButtonListener(ActionListener exportMediaListener) {
		
	}
	
	/**
	 * Registers save listener.
	 * @param saveMediaListener Listener to register.
	 */
	public void addSaveMediaButtonListener(ActionListener saveMediaListener) {
		
	}
	
	/**
	 * Registers pie chart listener.
	 * @param pieChartListener Listener to register.
	 */
	public void addPieChartButtonListener(ActionListener pieChartListener) {
		
	}
	
	/**
	 * Registers histogram listener.
	 * @param histogramListener Listener to register.
	 */
	public void addHistogramButtonListener(ActionListener histogramListener) {
		
	}
}
