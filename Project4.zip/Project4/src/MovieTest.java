import static org.junit.Assert.*;

import org.junit.Test;

public class MovieTest {

	@Test
	public void test() {
		String movie = "Our Star Trek Moment (2014) (V)             2014";
		Movie m = new Movie(movie);
		assertEquals(m.getTitle(), "Our Star Trek Moment");
		assertEquals(m.getReleaseYear(), "2014");
		assertEquals(m.getVenue(), "V");
	}

}
