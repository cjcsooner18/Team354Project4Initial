import java.awt.event.ActionEvent;

/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * MVC controller.
 * </p>
 * @version 1.0
 *
 */
public class MediaController {
	/**
	 * The model for the program.
	 */
	MediaModel model;
	
	/**
	 * The input window for the program.
	 */
	MediaInputWindow inputView;
	
	/**
	 * The constructor for the MediaController class.
	 */
	public MediaController() {
		
	}
	
	/**
	 * Sets the model for the GUI.
	 * @param model The model to be set.
	 */
	public void setModel(MediaModel model) {
		
	}
	
	/**
	 * Gets the GUI model.
	 * @return The MediaModel object.
	 */
	public MediaModel getModel() {
		return null;
	}
	
	/**
	 * Sets the input window.
	 * @param view The input window to be set.
	 */
	public void setInputWindow(MediaInputWindow view) {
		
	}
	
	public class AddMediaListener {
		/**
		 * Method to add media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class EditMediaListener {
		/**
		 * Method to edit media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class DeleteMediaListener {
		/**
		 * Method to delete media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class ClearMediaListener {
		/**
		 * Method to clear media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class ClearAllMediaListener {
		/**
		 * Method to clear all media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class ClearInputFieldsListener {
		/**
		 * Method to clear input media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class LoadMediaListener {
		/**
		 * Method to load media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class ImportMediaListener {
		/**
		 * Method to import media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class ExportMediaListener {
		/**
		 * Method to export media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class SaveMediaListener {
		/**
		 * Method to save media.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class PieChartListener {
		/**
		 * Method to create a pie chart.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	public class HistogramListener {
		/**
		 * Method to create a histogram.
		 * @param e The ActionEvent for the event.
		 */
		public void actionPerformed(ActionEvent e) {
			
		}
	}
}
