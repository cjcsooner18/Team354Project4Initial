/**
 * Project #4
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Program driver.
 * </p>
 * @version 1.0
 *
 */
public class Driver {
	/**
	 * Model for the GUI.
	 */
	MediaModel mediaModel;
	
	/**
	 * Input window for the GUI.
	 */
	MediaInputWindow inputWindow;
	
	/**
	 * Display window for the GUI.
	 */
	MediaDisplayWindow displayWindow;
	
	/**
	 * Controller for the GUI.
	 */
	MediaController controller;
	
	/**
	 * Main method for the program.
	 * @param args Program arguments.
	 */
	public void main(String[] args) {
		
	}
}
