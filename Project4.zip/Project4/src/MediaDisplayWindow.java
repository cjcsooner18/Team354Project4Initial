import java.awt.event.ActionEvent;

/**
 * Project #4
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * MVC controller.
 * </p>
 * @version 1.0
 *
 */
public class MediaDisplayWindow {
	/**
	 * Model for the GUI.
	 */
	private MediaModel model;
	
	/**
	 * Constructor for MediaDisplayWindow.
	 */
	public MediaDisplayWindow() {
		
	}
	
	/**
	 * Keeps track of actions performed.
	 * @param e ActionEvent that is performed.
	 */
	public void actionPerformed(ActionEvent e) {
		
	}
	
	/**
	 * Sets the model.
	 * @param model Model to be set.
	 */
	public void setModel(MediaModel model) {
		
	}
	
	/**
	 * Gets the model for the GUI.
	 * @return Returns the model.
	 */
	public MediaModel getModel() {
		return null;
	}
}
