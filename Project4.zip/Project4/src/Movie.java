/**
 * Project #4
 * CS 2334, 013
 * 3/31/2016
 * <p>
 * Class for parsing and creating movie objects.
 * </p>
 * @version 1.0
 *
 */
public class Movie extends Media {
	/**
	 * String to store the venue the movie was released in.
	 */
	String venue;
	
	/**
	 * Constructor for movie objects.
	 * @param line String line from text file to create a movie.
	 */
	public Movie(String line) {
		
	}
	
	/**
	 * Gets the venue for the movie.
	 * @return String object of the venue.
	 */
	public String getVenue() {
		return "";
	}
	
	/**
	 * To string method for movie objects.
	 * @return String representation of movie objects.
	 */
	public String toString() {
		return "";
	}
}
