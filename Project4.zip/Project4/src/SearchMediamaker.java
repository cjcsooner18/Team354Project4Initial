import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * Lab #5
 * CS 2334, Section 013
 * 3/31/2016
 * <p>
 * Search methods for mediamakers.
 * </p>
 * @version 1.0
 *
 */
public class SearchMediamaker {
	/**
	 * Searches for an exact mediamaker based on name.
	 * @param people LinkedHashMap database of mediamakers.
	 * @param key The name of the person.
	 * @return The mediamaker object.
	 */
	public Mediamaker searchExact(LinkedHashMap people, String key) {
		return null;
	}
	
	/**
	 * Searches for partial matches of mediamakers based on name.
	 * @param people LinkedHashMap database of mediamakers.
	 * @param key The name being searched for.
	 * @return An ArrayList of mediamaker matches.
	 */
	public ArrayList<Mediamaker> searchPartial(LinkedHashMap people, String key) {
		return null;
	}
}
